package coffeeshopsystem;
public class CoffeeShopSystem {
    CoffeeShopSystem()
	{
		new CoffeeShopHome(1);
	}
	public static void main(String[] args) {
		new CoffeeShopSystem();
	}
    
}
