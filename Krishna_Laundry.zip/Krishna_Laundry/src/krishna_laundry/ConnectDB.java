package krishna_laundry;
import java.sql.Connection;
import java.sql.DriverManager;
public class ConnectDB 
{
     Connection con=null;
     public Connection connect()
     {
         try
         {
             Class.forName("com.mysql.cj.jdbc.Driver");
             this.con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/krishnadb_new","root",""); 
            if(con !=null)
             {
                 System.out.println("Connection Established...");
             }
         }
         catch(Exception e)
         {
             System.out.println("Error in ConnectDB.java : "+e);
             
         }
         return this.con;
     }
     public void disconnect()
     {
         try
         {
             this.con.close();
             System.out.println("Connection Closed...");
         }
          catch(Exception e)
         {
             System.out.println("Error in ConnectDB.java : "+e);
             
         }
     }
     
  /*   public static void main(String ar[])
     {
         ConnectDB connectDb=new ConnectDB();
         connectDb.connect();
         connectDb.disconnect();
     }
   */
}
