package krishna_laundry;
public class Krishna_Laundry {
    public static void main(String[] args) {
        new Login().setVisible(true);
    }
    
}
